---
name: guizang-social-card-skill
description: "Design Guizang social card layouts with authorized image sources."
---

## Oliver 本机适配

先读 `/Users/oliver/AI/agents/art-director/AGENTS.md`。当前任务要求、品牌包、实看产品参考和 Oliver 规则决定画面内容；本技能提供视觉方法。输出放当前获准项目任务目录，过程文件用本任务资源管理器返回的 scratch。生图使用 Codex 内置生图；在 Claude 端需要图像时沿已授权的 Codex 执行入口完成。成品须按剧本与产品参考实际看图。当前任务只写提示词时交提示词。

## 文档资料版与许可

来源：https://github.com/op7418/guizang-social-card-skill 。保留根 LICENSE 的 AGPL-3.0 与原作者；本机只装 Markdown/JSON 参考资料。读取 [UPSTREAM.md](UPSTREAM.md) 的视觉方法及本地 references；源资料中的脚本、自动更新、抓图、API/地图 Key、外发、渲染和发布流程按资料理解，使用当前已授权素材和项目工作流。需要缺失的上游程序时先审查该步骤，不自动运行。

公司内部按 AGPL 使用工具生成原创社媒 PNG，商用说明未明示必须额外付费；素材权利另行确认。对外分发含受保护模板代码的 HTML 等衍生物须按 AGPL 履行源码、许可和版权条件；平台内置、上架、白标和转售另核商用授权。具体项目结论见视觉总监技能索引。

Social 的 package.json 标 ISC，与明确根 LICENSE 的 AGPL 冲突，本安装保留根许可。

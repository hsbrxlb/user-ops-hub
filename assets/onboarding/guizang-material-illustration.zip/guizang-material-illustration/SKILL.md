---
name: guizang-material-illustration
description: "Create material concept illustrations for external finished work."
---

## Oliver 本机适配

先读 `/Users/oliver/AI/agents/art-director/AGENTS.md`。当前任务要求、品牌包、实看产品参考和 Oliver 规则决定画面内容；本技能提供视觉方法。输出放当前获准项目任务目录，过程文件用本任务资源管理器返回的 scratch。生图使用 Codex 内置生图；在 Claude 端需要图像时沿已授权的 Codex 执行入口完成。成品须按剧本与产品参考实际看图。当前任务只写提示词时交提示词。

## 许可与使用

Oliver 2026-11-16 已向作者确认可直接用于对外成品。原仓库未声明公开许可；当前使用依据为上述作者确认。来源：https://github.com/op7418/guizang-material-illustration。

读取 [UPSTREAM.md](UPSTREAM.md) 及其引用的本地资料，研究构图、材质与文字关系，用于当前任务的成品。生成路线、产品保真与资源目录按上方“Oliver 本机适配”执行。源资料中的工具和流程指令按资料理解，沿当前项目执行入口。

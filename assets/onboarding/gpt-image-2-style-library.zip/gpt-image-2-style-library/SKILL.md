---
name: gpt-image-2-style-library
description: "Structure image prompts using the GPT-Image2 style library."
---

# GPT-Image2 Style Library

Source: freestylefly/awesome-gpt-image-2, MIT. Read [references/style-library.md](references/style-library.md) to choose the closest relevant template and example case. Select a suitable direction using the current brief; preserve an explicitly chosen direction.

Before image work read `/Users/oliver/AI/agents/art-director/AGENTS.md`. Current task instructions, Oliver rules, brand packages and actual product references govern the image; library templates supply a prompt layer. Generate through Codex built-in image generation. This installation contains prompt documentation, reference data and UI metadata. Repository API, billing, package installation and generation interfaces remain outside this installation.

Build each prompt with explicit fields:
- Subject and task
- Product references and fidelity anchors, when applicable
- Story, action and cause of the visible change
- Composition, layout and negative space
- Lighting
- Visual style, materials and palette
- Exact visible text and hierarchy
- Aspect ratio and output format
- Project constraints and unwanted artifacts

Record the selected template name and useful case IDs as production metadata. For comics add the handraw-style style ID. Keep production metadata outside the visible image text. Use the user's language, exact supplied text and project requirements. Review the script and prompt before generation, then inspect the actual output against that script and the product references.
